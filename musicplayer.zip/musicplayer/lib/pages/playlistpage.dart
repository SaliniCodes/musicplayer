import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class playlistpage extends StatelessWidget {
  const playlistpage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black12.withOpacity(0.6),
            Colors.black12.withOpacity(0.6),
          ],
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 20, horizontal: 25),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(CupertinoIcons.back,
                          color:Colors.white,
                          size: 30,
                        ), // Add icon or child widget here
                      ),
                      InkWell(
                        onTap: () {
                          // Navigator.pop(context);
                        },
                        child: Icon(Icons.more_vert,
                          color:Colors.white,
                          size: 30,
                        ), // Add icon or child widget here
                      ),
                    ],
                  ),
                ),
                SizedBox(height:10),
                ClipRRect(borderRadius: BorderRadius.circular(20),
                  child: Image.network('https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bXVzaWMlMjBiYWNrZ3JvdW5kfGVufDB8fDB8fHww', fit:BoxFit.cover,height: 260,width: 250,),
                ),
                SizedBox(width:25),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Imagine Dragon',style: TextStyle(
                      color:Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w400,
                    ),
                    ),
                    SizedBox(height:9),
                    Text('Singer Name',style: TextStyle(
                      color:Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w400,
                    ),
                    ),
                  ],
                ),
                SizedBox(height:30),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              InkWell(
                onTap: (){},
                child: Container(
                  width:170,
                  height: 55,
                  decoration: BoxDecoration(
                      color: Colors.white,
                    borderRadius: BorderRadius.circular(8),


                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,

                    children:[
                      Text("Play All",style:TextStyle(color:Colors.blue,fontSize: 20,
                        fontWeight: FontWeight.bold,) ,),
                      SizedBox(width: 5,),

                      Icon(Icons.play_arrow_rounded,size: 40,color: Colors.pink,),
                    ],
                  ),
                ),

              ),
              InkWell(
                onTap: (){},
                child: Container(
                  width:170,
                  height: 55,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),


                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,

                    children:[
                      Text("Shuffle",style:TextStyle(color:Colors.blue,fontSize: 21,
                        fontWeight: FontWeight.bold,) ,),
                      SizedBox(width: 10,),
                      Icon(Icons.shuffle,size: 40,color: Colors.pink,),
                    ],
                  ),
                ),

              ),
              ],
          ),
                SizedBox(width: 20,),

            for(int i=1;i<20;i++)
          Container(
      margin: EdgeInsets.only(top:15,right: 12,left: 5),
      padding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
      decoration: BoxDecoration(color: Colors.white70,borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Text(
              i.toString(),
              style:TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w400,
              )
          ),
          SizedBox(width: 25,),
          InkWell(
                      onTap: (){
                        Navigator.pushNamed(context,"musicpage");
            },
            child:Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("imagin Dragons = Believer",
                    style:TextStyle(
                      color: Colors.pink,
                      fontSize:17,
                      fontWeight: FontWeight.bold,
                    ))
              ],

            ),


          ),
          Spacer(),
          Container(height: 35,width: 35,
            decoration: BoxDecoration(color: Colors.white70,borderRadius: BorderRadius.circular(30)),
            child: Icon(Icons.play_arrow,size: 25,color: Colors.pink,),
          ),
          ],
          ),
        ),],
      ),),)
      ),);
  }
}
