import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class musicpage extends StatelessWidget {
  const musicpage({super.key});

  @override
  Widget build(BuildContext context) {
    return (Container(
      decoration: BoxDecoration(
        image: DecorationImage(image: NetworkImage('https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bXVzaWMlMjBiYWNrZ3JvdW5kfGVufDB8fDB8fHww',),
        fit: BoxFit.cover)
      ),
      child: Scaffold(backgroundColor: Colors.transparent,
        body: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black.withOpacity(0.3),
                      Colors.black.withOpacity(0.5)
                    ]
                )

            ),
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
child: Column(
  children: [Padding(padding: EdgeInsets.symmetric(vertical: 45,horizontal: 45),
  child: Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      InkWell(
      onTap: (){
          Navigator.pop(context);
          },   child: Icon(CupertinoIcons.back,color:Colors.black ,size: 30,
          ),
      ),
      InkWell(
        onTap: (){
          // Navigator.pop(context);
        },   child: Icon(Icons.more_vert,color:Colors.black ,size: 30,
      ),
      ),],
  ),),
    Spacer(),

    Container(color: Colors.white,
      height: MediaQuery.of(context).size.height/2.5,
          child:Column(children: [
            SizedBox(height: 40,),
            Padding(padding: EdgeInsets.symmetric(vertical: 23,horizontal: 20),child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(children: [
                  Text('Imagine Dragon',style: TextStyle(
                    color:Colors.pink,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                  ),
                ],),
                Icon(Icons.favorite,color:Colors.pink,size: 35,)
              ],
            ),),
            Column(children: [
              Slider(min:0,
              max: 100,value: 40,
              onChanged: (value){},
              activeColor: Colors.pink,inactiveColor: Colors.pink,),
              Padding(padding: EdgeInsets.symmetric(horizontal: 25),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [Text('2:10',style: TextStyle(
                  color:Colors.pink,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                ),Text('4:10',style: TextStyle(
                  color:Colors.pink,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                ),],
              ))
          ],

    ),
    SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Icon(Icons.list,color: Colors.pink,size: 15,),
                Icon(CupertinoIcons.backward_end_fill,color: Colors.pink,size: 15,),
                Container(
                  alignment: Alignment.center,
                  height: 40,
                  width: 40,
                  decoration: BoxDecoration(
                    color: Colors.pink,
                    borderRadius: BorderRadius.circular(30)
                  ),
                  child: Icon(CupertinoIcons.play_arrow,color: Colors.black,size: 15,),

                ),
                Icon(CupertinoIcons.forward_end_fill,color: Colors.pink,size: 15,),
                Icon(Icons.download,color: Colors.pink,size: 15,),


              ],
            )

  ],
),
          ),

     ], ),
    ),),),));
  }
}
