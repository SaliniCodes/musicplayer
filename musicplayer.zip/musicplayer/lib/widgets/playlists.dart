import 'package:flutter/material.dart';
class playlists extends StatelessWidget {
  const playlists({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          for(int i=1;i<20;i++)
          Container(
            margin: EdgeInsets.only(top: 20,right:20,left: 5 ),
            padding: EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(15),

            ),
            child: Row(
              children: [InkWell(
                onTap: (){
                  Navigator.pushNamed(context, "playlistpage");
                },
                child: ClipRRect(borderRadius: BorderRadius.circular(10),
                child: Image.network('https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bXVzaWMlMjBiYWNrZ3JvdW5kfGVufDB8fDB8fHww', fit:BoxFit.cover,height: 60,width: 60,),
               ),
              ),SizedBox(width:25),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Imagine Dragon',style: TextStyle(
                      color:Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w400,
                    ),
                        ),
                    SizedBox(height:5),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
