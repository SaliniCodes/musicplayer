import 'package:flutter/material.dart';
class MusicLists extends StatelessWidget {
  const MusicLists({super.key});

  @override
  Widget build(BuildContext context) {
    return  SingleChildScrollView(child: Column(children: [

      SizedBox(height: 15,),
      for(int i=1;i<20;i++)
      Container(
        margin: EdgeInsets.only(top:15,right: 12,left: 5),
        padding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
        decoration: BoxDecoration(color: Colors.white70,borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Text(
              i.toString(),
                  style:TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                  )
            ),
            SizedBox(width: 25,),
            InkWell(
              onTap: (){
                Navigator.pushNamed(context,"musicpage");
    },
              child:Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("imagin Dragons = Believer",
                  style:TextStyle(
                    color: Colors.pink,
                        fontSize:17,
                    fontWeight: FontWeight.bold,
                  ))
                ],

              ),


            ),
            Spacer(),
            Container(height: 35,width: 35,
            decoration: BoxDecoration(color: Colors.white70,borderRadius: BorderRadius.circular(30)),
            child: Icon(Icons.play_arrow,size: 25,color: Colors.pink,),
            ),
          ],
        ),

      ),
    ],),);
  }
}
